﻿using System;
using System.Collections.Generic;
using System.IO;

namespace DataAccess
{
    public class PaymentRepository : IPaymentRepository
    {
        private static string FilePath;

        public PaymentRepository()
        {
            string path = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
            path = path.Substring(0, path.Length - 3);

            string fileName = "PaymentLogs.txt";

            FilePath = path + fileName;
        }

        public PaymentRepository(string filePath) => FilePath = filePath;


        /// <summary>
        /// Given a log message string, adds it to the logs file.
        /// If file is not found, creates the file then adds the log.
        /// </summary>
        /// <param name="paymentMessage"></param>
        public void Add(string paymentMessage)
        {
            if (!File.Exists(FilePath))
            {
                Console.WriteLine("Logs file could not be found. I generated it and added the logs.");
                File.WriteAllText(FilePath, paymentMessage + "\n");
            }
            else if (File.Exists(FilePath))
            {
                using (TextWriter textWriter = new StreamWriter(FilePath, true))
                    textWriter.WriteLine(paymentMessage);
            }
        }

        // Implementation not requested
        IEnumerable<string> IRepository<string>.GetAll()
        {
            throw new NotImplementedException();
        }
    }
}