﻿using System;
namespace DataAccess.UnitOfWork
{
    public class UnitOfWork
    {
        private PaymentRepository paymentRepository;

        public PaymentRepository PaymentRepository
        {
            get
            {
                if (this.paymentRepository == null)
                    this.paymentRepository = new PaymentRepository();
                return paymentRepository;
            }
        }
    }
}
